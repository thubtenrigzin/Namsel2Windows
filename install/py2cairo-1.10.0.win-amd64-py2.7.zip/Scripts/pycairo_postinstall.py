"""pycairo is now installed on your machine.

Local configuration files were successfully updated."""

import os.path, re, sys, tempfile
import distutils.sysconfig
import distutils.file_util
import distutils.errors

prefix_pattern=re.compile("^prefix=.*")

pkgname = "pycairo"

#Send output somewhere so it can be found if necessary...
tee_f = open(os.path.join(
        tempfile.gettempdir(),
        "%s_postinstall.log" % pkgname), "w")
class Tee:
    def __init__(self, file):
        self.f = file
    def write(self, what):
        self.f.write(what)
        tee_f.write(what)

sys.stderr = Tee(sys.stderr)
sys.stdout = Tee(sys.stdout)

def replace_prefix(s):
    if prefix_pattern.match(s):
        s='prefix='+sys.prefix.replace("\\","/")+'\n'
    return s
    
if len(sys.argv) == 2:
    if sys.argv[1] == "-install":
        #install any files that need their prefixes adjusted
        # (usually pkg-config files)
        filenames=['lib/pkgconfig/pycairo.pc']
        for filename in filenames: 
            file_ = os.path.normpath(
                os.path.join(sys.prefix,filename))

            lines=open(file_).readlines()
            open(file_, 'w').writelines(map(replace_prefix,lines))
        print __doc__
    elif sys.argv[1] == "-remove":
        #never gets called...
        print "%s was uninstalled" % pkgname
